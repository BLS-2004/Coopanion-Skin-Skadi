/**
 * Coopanion body for the complete Arknights Skadi packs.
 * One WebGL context is reused for every skin/form; scheme changes only swap skeleton data and textures.
 */
const SVG_NS = 'http://www.w3.org/2000/svg';
const XHTML_NS = 'http://www.w3.org/1999/xhtml';
const RUNTIME = 'runtime/spine-webgl-3.8.js';
/* Drawing geometry. The body stands inside the kit's 256-unit box with its feet on the ground line
   (y = 256) and its own origin at the feet, so the stage maps it 1:1. Effects may reach past the box
   into MARGIN units of extra room on every side; the box itself is never scaled to fit them. */
const MARGIN = 128;
const REGION = 256 + MARGIN * 2;
const PX_PER_UNIT = 2;
const TARGET_H = 230;
const TARGET_W = 240;
/* Lying and sitting poses draw a little under the feet line; the pet window ends 2px under the floor
   (the taskbar covers the rest), so lift just those poses by this much. */
const GROUND_LIFT = 8;
const CACHE = new Map();
const WORDS = {
  abyss: { expression: { like: 'determined', seconds: 1.6 } },
  cold: { expression: { like: 'smug', seconds: 1.5 } },
  sing: { expression: { like: 'happy', seconds: 1.8 } },
  tide: { expression: { like: 'thinking', seconds: 1.8 } },
  seabreeze: { expression: { like: 'happy', seconds: 1.6 } },
  alert: { expression: { like: 'surprised', seconds: 1.3 } },
  sword: { motion: { seconds: 1.7, face: 'determined' } },
  sweep: { motion: { seconds: 1.7, face: 'determined' } },
  summon: { motion: { seconds: 1.7, face: 'determined' } },
  pose: { motion: { seconds: 1.7, face: 'smug' } },
  salute: { motion: { seconds: 1.7, face: 'determined' } },
  hunt: { motion: { seconds: 1.7, face: 'smug' } },
  tidecall: { motion: { seconds: 1.7, face: 'thinking' } },
  attack: { motion: { seconds: 1.7, face: 'determined' } },
  skill: { motion: { seconds: 1.7, face: 'determined' } },
  skill1: { motion: { seconds: 1.7, face: 'determined' } },
  skill2: { motion: { seconds: 1.7, face: 'determined' } },
  skill3: { motion: { seconds: 1.7, face: 'determined' } },
  special: { motion: { seconds: 3.0, face: 'neutral' } },
  start: { motion: { seconds: 1.2, face: 'neutral' } },
  die: { motion: { seconds: 1.2, face: 'sad' } },
  stun: { motion: { seconds: 2.2, face: 'dizzy' } },
};
const FACE_ALIASES = {
abyss: 'determined', cold: 'smug', tide: 'thinking', sing: 'happy', seabreeze: 'happy', alert: 'surprised',
  sword: 'determined', sweep: 'determined', summon: 'determined', pose: 'smug', salute: 'determined',
  hunt: 'smug', tidecall: 'thinking', attack: 'determined', skill: 'determined', skill1: 'determined',
  skill2: 'determined', skill3: 'determined', special: 'neutral', start: 'neutral', die: 'sad', stun: 'dizzy',
};
/* How long the body waits between two actions it starts by itself. Long enough that the pet only
   stirs now and then instead of fidgeting every few seconds. */
const AUTO_IDLE_MIN = 30, AUTO_IDLE_SPAN = 30;
const lerp = (a, b, k) => a + (b - a) * k;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
function firstAnimation(data, names) {
  for (const n of names) if (data.findAnimation(n)) return n;
  return data.animations[0]?.name || 'Default';
}
function animationDuration(data, name) {
  return data.findAnimation(name)?.duration || 0;
}
function atlasPages(text) {
  const lines = text.split(/\r?\n/);
  const pages = [];
  for (let i = 0; i < lines.length - 1; i++) {
    const line = lines[i].trim();
    if (line && /^size\s*:/i.test(lines[i + 1].trim()) && /^format\s*:/i.test((lines[i + 2] || '').trim())) pages.push(line);
  }
  return pages;
}
function loadSpine(base) {
  if (globalThis.spine?.webgl) return Promise.resolve(globalThis.spine);
  let pending = CACHE.get('spine');
  if (pending) return pending;
  pending = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = new URL(RUNTIME, base).href;
    s.onload = () => globalThis.spine?.webgl ? resolve(globalThis.spine) : reject(new Error('Spine WebGL runtime missing webgl namespace'));
    s.onerror = () => reject(new Error('Spine WebGL runtime failed to load'));
    document.head.appendChild(s);
  });
  CACHE.set('spine', pending);
  return pending;
}
function boundsOf(spine, data, name) {
  const sk = new spine.Skeleton(data);
  const st = new spine.AnimationState(new spine.AnimationStateData(data));
  st.setAnimation(0, name, true);
  const duration = Math.max(0, animationDuration(data, name));
  const steps = Math.max(1, Math.ceil(duration * 30));
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (let i = 0; i < steps; i++) {
    if (i) st.update(duration / steps);
    st.apply(sk);
    sk.updateWorldTransform();
    const off = new spine.Vector2(), size = new spine.Vector2();
    sk.getBounds(off, size);
    if (Number.isFinite(off.x) && Number.isFinite(off.y) && size.x > 0 && size.y > 0) {
      minX = Math.min(minX, off.x); minY = Math.min(minY, off.y);
      maxX = Math.max(maxX, off.x + size.x); maxY = Math.max(maxY, off.y + size.y);
    }
  }
  return Number.isFinite(minX) ? { minX, minY, maxX, maxY } : { minX: -200, minY: 0, maxX: 200, maxY: 400 };
}
/* A body that has a back drawn (a B_ head/hair slot) can be held facing away: find one moment
   where the back head is on and the front head art is off. Styles drawn front-only give null. */
function backHeadSlots(data) {
  return data.slots.filter(s => /^B_(Head|Hair|Face|Back_Hair)/i.test(s.name)).map(s => s.name);
}
function backPoseOf(spine, data) {
  const backHead = backHeadSlots(data);
  if (!backHead.length) return null;
  const frontHead = data.slots.filter(s => /^(F_(Head|Face|Hair)|F_Eye|F_Eyelash|F_Eyebrow|F_Mouth|F_Bangs)/i.test(s.name)).map(s => s.name);
  const names = data.animations.map(a => a.name);
  names.sort((a, b) => (/idle|relax|move/i.test(b) ? 1 : 0) - (/idle|relax|move/i.test(a) ? 1 : 0));
  const sk = new spine.Skeleton(data), st = new spine.AnimationState(new spine.AnimationStateData(data));
  for (const name of names) {
    st.clearTrack(0); st.setAnimation(0, name, false);
    const dur = Math.max(0.0001, animationDuration(data, name));
    for (let i = 0; i <= 48; i++) {
      const t = dur * i / 48, cur = st.getCurrent(0);
      if (!cur) continue;
      cur.trackTime = t; st.apply(sk); sk.updateWorldTransform();
      let back = 0, front = 0;
      for (const n of backHead) { const sl = sk.findSlot(n); if (sl && sl.attachment) back++; }
      for (const n of frontHead) { const sl = sk.findSlot(n); if (sl && sl.attachment) front++; }
      if (back > 0 && front === 0) return { clip: name, time: t };
    }
  }
  return null;
}
function buildFaceMap(data) {
  const slots = data.slots.map(s => s.name);
  const bySlot = new Map();
  for (const entry of data.skins[0].getAttachments()) {
    const slot = slots[entry.slotIndex];
    if (!bySlot.has(slot)) bySlot.set(slot, []);
    bySlot.get(slot).push(entry.name);
  }
  const choose = (slot, names) => {
    const list = bySlot.get(slot) || [];
    for (const n of names) if (list.includes(n)) return n;
    return list[0] || null;
  };
  const eye = choose('F_Eye_1', ['F_Eye_1', 'F_Eye_2']);
  const side = choose('F_Eye_1', ['F_Eye_2', 'F_Eye_1']);
  const lash = (n) => choose('F_Eyelash_1', [`F_Eyelash_${n}`, 'F_Eyelash_1', 'F_Face']);
  const brow = (n) => choose('F_Eyebrow', [n === 1 ? 'F_Eyebrow' : `F_Eyebrow_${n}`, 'F_Eyebrow']);
  const mouth = (n) => choose('F_Mouth', [n === 1 ? 'F_Mouth' : `F_Mouth_${n}`, 'F_Mouth']);
  return {
    neutral: [eye, lash(1), brow(1), mouth(1)],
    happy: [null, lash(3), brow(1), mouth(4)],
    wink: [side, lash(1), brow(1), mouth(3)],
    love: [null, lash(3), brow(1), mouth(4)],
    shy: [side, lash(2), brow(3), mouth(3)],
    surprised: [eye, lash(4), brow(1), mouth(5)],
    angry: [eye, lash(1), brow(2), mouth(2)],
    sad: [eye, lash(2), brow(3), mouth(2)],
    sleepy: [null, lash(3), brow(1), mouth(1)],
    sleeping: [null, lash(3), brow(1), mouth(1)],
    sleep: [null, lash(3), brow(1), mouth(1)],
    thinking: [side, lash(1), brow(3), mouth(2)],
    smug: [side, lash(1), brow(4), mouth(3)],
    pout: [eye, lash(2), brow(5), mouth(2)],
    worried: [eye, lash(2), brow(3), mouth(2)],
    determined: [eye, lash(1), brow(2), mouth(1)],
    flustered: [side, lash(2), brow(4), mouth(5)],
    scared: [eye, lash(4), brow(4), mouth(5)],
    excited: [null, lash(3), brow(1), mouth(4)],
    cry: [null, lash(5), brow(3), mouth(2),],
    confused: [side, lash(1), brow(4), mouth(2)],
    bowing: [null, lash(3), brow(5), mouth(1)],
    content: [eye, lash(1), brow(1), mouth(3)],
    listening: [eye, lash(1), brow(1), mouth(1)],
    run: [eye, lash(1), brow(2), mouth(2)],
    dizzy: [null, lash(6), brow(4), mouth(5)],
    abyss: [eye, lash(1), brow(2), mouth(1)],
    cold: [side, lash(1), brow(4), mouth(3)],
    tide: [side, lash(1), brow(3), mouth(2)],
  };
}
function makeClipMap(data) {
  const pick = (...names) => firstAnimation(data, names);
  return {
    idle: pick('Relax', 'Idle', 'Default'),
    move: pick('Move', 'Idle', 'Default'),
    sit: pick('Sit', 'Idle', 'Default'),
    sleep: pick('Sleep', 'Idle', 'Default'),
    interact: pick('Interact', 'Idle', 'Default'),
    attack: pick('Attack', 'Attack_Begin', 'Skill_1_Begin', 'Interact', 'Idle', 'Default'),
    skill: pick('Skill_1_Begin', 'Skill_1_Loop', 'Attack', 'Interact', 'Idle', 'Default'),
    skill1: pick('Skill_1_Begin', 'Skill_1_Loop', 'Attack', 'Interact', 'Idle', 'Default'),
    skill2: pick('Skill_2_Begin', 'Skill_2_Loop', 'Skill_1_Begin', 'Skill_1_Loop', 'Attack', 'Interact', 'Idle', 'Default'),
    skill3: pick('Skill_3_Begin', 'Skill_3_Loop', 'Skill_1_Begin', 'Skill_1_Loop', 'Attack', 'Interact', 'Idle', 'Default'),
    special: data.findAnimation('Special')?.name || null,
    attackBegin: data.findAnimation('Attack_Begin')?.name || null,
    attackEnd: data.findAnimation('Attack_End')?.name || null,
    start: pick('Start', 'Appear', 'Interact', 'Relax', 'Move', 'Default'),
    die: pick('Die', 'Sleep', 'Sit', 'Idle', 'Default'),
    stun: pick('Stun_Begin', 'Stun', 'Dizzy', 'Sit', 'Sleep', 'Idle', 'Relax', 'Default'),
    /* The kit's dizzy mode lasts about three seconds: fall over once (Stun_Begin), then lie there
       looping the real stun state. Looping the fall instead reads as the same action done over. */
    stunLoop: pick('Stun', 'Stun_Loop', 'Stun_Begin', 'Dizzy', 'Idle', 'Default'),
  };
}
/* The words this pack performs itself. One asked for while another is still playing waits in line
   instead of cutting in, so every action gets to finish; being picked up or thrown is the one thing
   allowed to take over mid-action. */
const ACTION_WORDS = new Set(['attack', 'sword', 'sweep', 'hunt', 'skill', 'skill1', 'skill2', 'skill3',
  'summon', 'tidecall', 'pose', 'salute', 'wave', 'bow', 'special',
  'start', 'die', 'stun']);
function clipOf(model, kind) {
  const c = model.clips, battle = model.form === 'battle';
  switch (kind) {
    case 'attack': return c.attack;
    case 'skill': return c.skill;
    case 'skill1': return c.skill1;
    case 'skill2': return c.skill2;
    case 'skill3': return c.skill3;
    case 'special': return c.special;
    case 'start': return c.start;
    case 'die': return c.die;
    case 'stun': return c.stun;
    case 'sword': case 'sweep': case 'hunt': return battle ? c.attack : c.interact;
    case 'summon': case 'tidecall': return battle ? c.skill : c.interact;
    case 'pose': case 'salute': case 'wave': case 'bow': return battle ? c.attack : c.interact;
    default: return null;
  }
}
function planFor(model, frame, elapsed, idleT) {
  const g = frame?.gesture;
  const mode = frame?.mode || 'idle';
  const c = model.clips;
  const battle = model.form === 'battle';
  /* A word plays its clip once, at the speed the clip was authored at: `elapsed` is the wall time
     since the word started, not a 0..1 progress, so a long clip is never rushed through. */
  const once = (clip) => ({ clip, time: Math.max(0, elapsed || 0), loop: false, clamp: true });
  const held = (clip, progress) => ({ clip, progress: clamp(progress || 0, 0, 1), loop: false });
  const timed = (clip, time, loop = true, clampTime = false) => ({ clip, time: time || 0, loop, clamp: clampTime });
  /* A held body just hangs there: no word, no idle action, nothing plays while it is being dragged. */
  if (mode === 'drag') return model.backPose ? { clip: model.backPose.clip, time: model.backPose.time, loop: false, clamp: true } : held(c.idle, 0.42);
  if (g?.kind) {
    const clip = clipOf(model, g.kind);
    /* our own actions are drawn from the queue alone: a leftover pulse (say, one cut off by being
       grabbed) must not sneak the tail of that action back on screen */
    if (clip && !ACTION_WORDS.has(g.kind)) return once(clip);
    if (g.kind === 'nod' || g.kind === 'shake') return timed(c.idle, idleT, true);
  }
  if (mode === 'walk' || mode === 'run') {
    /* A battle set has no walk cycle: its legs are borrowed from the idle loop. Stepping then has to
       keep the idle phase, otherwise every step restarts the loop at frame zero and the idle the
       player was watching looks cut in half. A set with a real Move clip still walks on modeT. */
    if (c.move === c.idle) return timed(c.idle, idleT, true);
    return timed(c.move, frame.modeT || 0, true);
  }
  if (mode === 'dance') {
    if (c.move === c.idle) return timed(c.idle, idleT, true);
    return timed(c.move, frame.modeT || 0, true);
  }
  if (mode === 'sit') {
    /* Sitting without a Sit clip is just the idle loop held: restart it from zero and the idle
       animation snaps back to its first frame every time the body sits down. The wake branch below
       already does this for getting up; sitting itself was missed. */
    if (c.sit === c.idle) return timed(c.idle, idleT, true);
    return timed(c.sit, frame.modeT || 0, false, true);
  }
  if (mode === 'sleep') {
    /* the battle chibi has no sleep at all; a building chibi loops its Sleep clip so it breathes while
       it sleeps instead of freezing on the last frame */
    if (battle) return timed(c.idle, idleT, true);
    return timed(c.sleep, frame.modeT || 0, true);
  }
  if (mode === 'wake') {
    /* Battle sets have no Sit track, so "sitting" is the idle loop: getting up is simply the idle
       continuing — scrubbing anything here only made poses snap. A real sit animation is walked
       back through its last 1.8 s, never faster than about 2x. */
    if (c.sit === c.idle) return timed(c.idle, idleT, true);
    const dur = animationDuration(model.data, c.sit);
    const span = Math.min(dur, 1.8), from = Math.max(0, dur - span);
    const k = clamp((frame.modeT || 0) / 0.9, 0, 1);
    return { clip: c.sit, time: from + span * (1 - k), loop: false, clamp: true };
  }
  /* being lifted, thrown or landing is a pose, not one of the pack's actions */
  if (mode === 'crouch') return held(c.idle, 0.68);
  if (mode === 'air') return held(c.idle, 0.5);
  if (mode === 'land') return held(c.idle, 0.18);
  if (mode === 'drag') return held(battle ? c.attack : c.interact, 0.42 + 0.05 * Math.sin((frame.t || 0) * 8));
  if (mode === 'dizzy') {
    const begin = battle ? c.stun : c.idle, loop = battle ? (c.stunLoop || c.stun) : c.idle;
    const dur = animationDuration(model.data, begin), mt = frame.modeT || 0;
    if (mt < dur) return { clip: begin, time: mt, loop: false, clamp: true };
    return timed(loop, mt - dur, true);
  }
  return timed(c.idle, idleT, true);
}
export async function createSkadiCompleteBody(base, opts) {
  const spine = await loadSpine(base);
  const styles = await (await fetch(new URL('styles.json', base))).json();
  const styleIds = Object.keys(styles);
  const canvas = document.createElementNS(XHTML_NS, 'canvas');
  canvas.width = REGION * PX_PER_UNIT; canvas.height = REGION * PX_PER_UNIT;
  canvas.style.cssText = 'width:100%;height:100%;display:block';
  const context = new spine.webgl.ManagedWebGLRenderingContext(canvas, { alpha: true, antialias: true, premultipliedAlpha: true, preserveDrawingBuffer: !!globalThis.__SKADI_CAPTURE });
  const renderer = new spine.webgl.SceneRenderer(canvas, context, true);
  renderer.camera.viewportWidth = REGION; renderer.camera.viewportHeight = REGION; renderer.camera.position.set(0, 128, 0);
  const models = new Map();
  let active = null, mounted = null, foreign = null;
  let entry = null, activeClip = '', disposed = false;
  let gestureKind = null, gestureStart = 0, pending = false, pendingAt = 0, nextAutoAt = AUTO_IDLE_MIN + Math.random() * AUTO_IDLE_SPAN, body = null, prevMode = '', crashChoice = null;
  let act = null, lastK = 0, clock = 0, clockT = null, kitDo = null, actGapUntil = 0, thrown = false;
  /* The idle loop keeps a clock of its own instead of riding the page clock. Run it off the page
     clock and every action, step or sit in between fast-forwards it, so the idle came back
     part-way through its cycle instead of carrying on from where it stopped. */
  let idleT = 0, idleAdvance = true;
  let drawnPose = null, grabHold = null;
  /* Our own action words are drawn as a shuffled round instead of rolled at random: the same
     one never fires twice in a row, and a short list is simply looped through. */
  let ownBag = [], lastOwnWord = null;
  const queue = [];
  async function loadModel(id, entryData) {
    const atlasUrl = new URL(entryData.atlas, base);
    const atlasText = await (await fetch(atlasUrl)).text();
    const pages = atlasPages(atlasText);
    const images = await Promise.all(pages.map(name => opts.loadImage(new URL(name, atlasUrl))));
    const textures = new Map();
    const textureFor = (name) => {
      if (!textures.has(name)) textures.set(name, new spine.webgl.GLTexture(context, images[pages.indexOf(name)] || images[0], false));
      return textures.get(name);
    };
    const atlas = new spine.TextureAtlas(atlasText, textureFor);
    const skel = new Uint8Array(await (await fetch(new URL(entryData.skel, base))).arrayBuffer());
    const data = new spine.SkeletonBinary(new spine.AtlasAttachmentLoader(atlas)).readSkeletonData(skel);
    const coreName = firstAnimation(data, entryData.form === 'battle' ? ['Default', 'Idle'] : ['Default', 'Relax', 'Idle']);
    const core = boundsOf(spine, data, coreName);
    const coreH = Math.max(1, core.maxY);
    const coreW = Math.max(1, core.maxX - core.minX);
    const fit = Math.min(TARGET_H / coreH, TARGET_W / coreW) * (entryData.scale || 1);
    const backPose = backPoseOf(spine, data), backHead = backHeadSlots(data);
    const model = { id, form: entryData.form, skin: entryData.skin, scale: fit, anchorX: (core.minX + core.maxX) / 2, backPose, backHead, textures, atlas, data, skeleton: new spine.Skeleton(data), state: new spine.AnimationState(new spine.AnimationStateData(data)), face: buildFaceMap(data), clips: makeClipMap(data) };
    return model;
  }
  async function switchStyle(id) {
    let model = models.get(id);
    if (!model) { const entryData = styles[id] || styles[styleIds[0]]; model = await loadModel(id, entryData); models.set(id, model); }
    active = model; entry = null; activeClip = ''; pending = false; pendingAt = 0; crashChoice = null; prevMode = ''; clock = 0; clockT = null;
    act = null; queue.length = 0; gestureKind = null; clockT = null; ownBag.length = 0; lastOwnWord = null;
    idleT = 0; idleAdvance = true; return model;
  }
  await switchStyle(opts.scheme && styles[opts.scheme] ? opts.scheme : styleIds[0]);
  function mount(petG) {
    if (mounted === petG && foreign?.parentNode === petG) return;
    mounted = petG; petG.textContent = '';
    foreign = document.createElementNS(SVG_NS, 'foreignObject'); foreign.setAttribute('x', String(-MARGIN)); foreign.setAttribute('y', String(-MARGIN)); foreign.setAttribute('width', String(REGION)); foreign.setAttribute('height', String(REGION)); foreign.appendChild(canvas);
    petG.append(foreign);
  }
  /* The pack's own actions also fire by themselves: a poke, a stroke, or a stretch of standing about asks
     the body to do one, so no action stays invisible until a command comes. The request goes through the
     kit's own do(), which keeps its timing, face and follow-up in step with everything else. */
  /* Every distinct clip the pack draws, except 入场 (that one is saved for the crash landing below).
     Different names that resolve to the same Spine clip are merged here. */
  const BUILDING_ACTIONS = ['attack', 'special'];
  const BATTLE_ACTIONS = ['attack'];
  function actionClips(word, clip) {
    const c = active?.clips;
    if (clip && c && clip === c.attack && c.attackBegin && c.attackEnd && c.attackBegin !== clip && c.attackEnd !== clip) {
      return [c.attackBegin, clip, c.attackEnd];
    }
    return [clip];
  }
  function actionPlan(a, t) {
    let elapsed = Math.max(0, t - a.start);
    for (let i = 0; i < a.clips.length; i++) {
      const clip = a.clips[i];
      const dur = animationDuration(active.data, clip);
      if (elapsed < dur || i === a.clips.length - 1) return { clip, time: elapsed, loop: false, clamp: true };
      elapsed -= dur;
    }
    return { clip: a.clips[a.clips.length - 1], time: 0, loop: false, clamp: true };
  }
  function startAct(word) {
    const clip = active && clipOf(active, word);
    if (!clip) return false;
    const clips = actionClips(word, clip);
    const len = clips.reduce((n, c) => n + animationDuration(active.data, c), 0);
    /* a 0-second clip is a still pose, not an action: playing it would be a sub-second flash */
    if (len < 0.3) return false;
    act = { word, clips, start: clock, dur: len, face: WORDS[word]?.motion?.face || null };
    /* the kit still does its own half of a word: the face it holds, its pulse, and standing still. */
    kitDo?.(word);
    gestureKind = word; lastK = 0;
    return true;
  }
  /* A word of ours never fires straight away: it is queued, so a burst from the bot plays one after
     another in full instead of overwriting each other inside the kit. */
  function enqueue(word) {
    /* asking for what is already on screen changes nothing */
    if (act && act.word === word) return true;
    /* one action may wait its turn; anything past that is dropped rather than stacked into a
       burst of actions running back to back */
    if (act || queue.length) { if (!queue.length && queue[0] !== word) queue.push(word); return true; }
    return startAct(word);
  }
  function playOwn() {
    if (!body || !active) return false;
    const words = active.form === 'battle' ? BATTLE_ACTIONS : BUILDING_ACTIONS;
    const pool = words.filter((w) => {
      const clip = clipOf(active, w);
      return clip && animationDuration(active.data, clip) >= 0.3;
    });
    if (!pool.length) return false;
    /* One pass over every action, reshuffled each time the round runs out, so a short list loops
       instead of rolling the same word twice in a row. */
    ownBag = ownBag.filter((w) => pool.indexOf(w) >= 0);
    if (!ownBag.length) {
      ownBag = pool.slice();
      for (let i = ownBag.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const t = ownBag[i]; ownBag[i] = ownBag[j]; ownBag[j] = t;
      }
      if (ownBag.length > 1 && ownBag[0] === lastOwnWord) {
        const k = 1 + Math.floor(Math.random() * (ownBag.length - 1));
        const t = ownBag[0]; ownBag[0] = ownBag[k]; ownBag[k] = t;
      }
    }
    const word = ownBag[0];
    if (body.do(word) === false) return false;
    ownBag.shift(); lastOwnWord = word;
    return true;
  }
  function noteEvent(kind, detail) {
    if (kind !== 'touch' || !detail) return;
    if (detail.kind === 'poke' || detail.kind === 'pet') pending = true;
    if (detail.kind === 'crash') crashChoice = Math.random() < 0.5 ? 'die' : 'stun';
  }
  function applyFace(model, faceName, face, frame) {
    const name = FACE_ALIASES[faceName] || faceName;
    const look = model.face[name] || model.face.neutral;
    let [eye, lashes, brow, mouth] = look;
    const blink = Math.max(frame?.eyeClose || 0, frame?.blink || 0);
    if (blink > 0.46) { eye = null; lashes = model.face.sleepy[1]; }
    if ((frame?.talk || 0) > 0.12) mouth = Math.sin((frame?.t || 0) * 24) > 0 ? look[3] : look[3];
    const away = (model.backHead || []).some((n) => { const s = model.skeleton.findSlot(n); return s && s.attachment; });
    const set = (slot, name) => {
      const s = model.skeleton.findSlot(slot);
      /* turned away: the animation owns the face (front parts would land on the back of the head).
         facing us: the face is ours, so a clip that has not keyed the slots yet cannot blank the eyes. */
      if (!s || away) return;
      s.setAttachment(name ? model.skeleton.getAttachment(s.data.index, name) : null);
    };
    set('F_Eye_1', eye); set('F_Eyelash_1', lashes); set('F_Eyebrow', brow); set('F_Mouth', mouth);
  }
  function draw(petG, face, frame) {
    if (disposed || !active) return;
    mount(petG);
    const rawT = frame?.t || 0, mode = frame?.mode || 'idle', g = frame?.gesture;
    /* Our own clock, stepped a frame at a time, so a hiccup in the page's clock can never make an
       action jump straight to its end. */
    const step = clockT == null ? 1 / 60 : Math.max(0, Math.min(0.1, rawT - clockT));
    clockT = rawT; clock += step;
    if (idleAdvance) idleT += step;
    const t = clock;
    if ((g?.kind || null) !== gestureKind) { gestureKind = g?.kind || null; gestureStart = t; }
    /* Only a hand on the body may cut an action short: being picked up, thrown on (air/land after a
       drag) or the dizzy of a hard crash. A hop or jump the body decides on its own does not. */
    if (mode === 'drag') thrown = true;
    const takeOver = mode === 'drag' || (!!crashChoice && mode === 'dizzy') || (thrown && (mode === 'air' || mode === 'crouch' || mode === 'land'));
    if (takeOver) {
      /* a grab that cuts an action short keeps the frame that was on screen: jumping to the back-view
         pose (which for the classic skins is another frame of the very same Attack clip) made the
         action look like it fast-forwarded and ended */
      if (mode === 'drag' && (act || queue.length) && drawnPose) grabHold = { ...drawnPose };
      act = null; queue.length = 0;
    }
    if (mode !== 'drag') grabHold = null;
    if (mode === 'idle') thrown = false;
    if (act && t - act.start >= act.dur) { act = null; actGapUntil = t + 1; }
    if (!act && queue.length && t >= actGapUntil) startAct(queue.shift());
    /* thrown hard: 眩晕 or 倒地 once the head clears, then 入场. Nowhere else do either of them play. */
    if (mode === 'idle' && prevMode === 'dizzy' && crashChoice && !g) {
      crashChoice = null;
      nextAutoAt = t + AUTO_IDLE_MIN + Math.random() * AUTO_IDLE_SPAN;
      if (active.form === 'battle') {
        playStartVoice();
        body?.do('start');   /* a building body has no entry animation */
      }
    }
    prevMode = mode;
    let acted = false;
    const busy = !!act || queue.length > 0;
    if (mode !== 'drag' && !busy) {
      if (pending) {
        if (!pendingAt) pendingAt = t;
        /* a poke or a stroke always gets an answer: wait for a playing action to end rather than
           dropping it, and do not insist that the body happens to be standing still */
        if (!g) { if (playOwn()) { pending = false; pendingAt = 0; acted = true; } }
        else if (t - pendingAt > 20) { pending = false; pendingAt = 0; }
      }
      if (!acted && !g && mode === 'idle' && t >= nextAutoAt) { nextAutoAt = t + AUTO_IDLE_MIN + Math.random() * AUTO_IDLE_SPAN; playOwn(); }
    }
    let plan = act ? actionPlan(act, t) : planFor(active, frame, t - gestureStart, idleT);
    if (!act && mode === 'drag' && grabHold) plan = { clip: grabHold.clip, time: grabHold.time, loop: false, clamp: true };
    if (!act && mode === 'dizzy' && crashChoice === 'die') plan = { clip: active.clips.die, time: frame.modeT || 0, loop: false, clamp: true };
    let clip = plan.clip || active.clips.idle;
    if (!active.data.findAnimation(clip)) clip = active.clips.idle;
    /* only a frame that really shows the idle loop moves its clock on */
    idleAdvance = clip === active.clips.idle;
    const anim = active.data.findAnimation(clip);
    let time = plan.time || 0;
    if (plan.progress != null) time = plan.progress * anim.duration;
    if (plan.reverse != null) time = (1 - plan.reverse) * anim.duration;
    if (plan.clamp) time = Math.min(time, Math.max(0, anim.duration - 0.0001));
    if (plan.loop && anim.duration > 0) time = ((time % anim.duration) + anim.duration) % anim.duration;
    if (clip !== activeClip) {
      /* No cross-fades here: clearTrack keeps the state from chaining a mixingFrom entry per clip
         change, which would otherwise be walked again on every single frame and slow the pet down
         the more actions it has played. */
      active.state.clearTrack(0);
      entry = active.state.setAnimation(0, clip, !!plan.loop);
      activeClip = clip;
    }
    if (!entry) entry = active.state.setAnimation(0, clip, !!plan.loop);
    entry.trackTime = time;
    drawnPose = { clip, time };
    active.state.apply(active.skeleton);
    applyFace(active, act?.face || face?.name || frame?.face || 'neutral', face, frame);
    const fit = active.scale || 1;
    active.skeleton.scaleX = fit; active.skeleton.scaleY = fit;
    active.skeleton.x = -active.anchorX * fit;
    const onFloor = mode === 'sit' || mode === 'sleep' || mode === 'dizzy' || mode === 'wake' || /die|sit|sleep|stun/i.test(clip);
    active.skeleton.y = onFloor ? GROUND_LIFT : 0;
    active.skeleton.updateWorldTransform();
    const gl = context.gl;
    gl.viewport(0, 0, canvas.width, canvas.height); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    renderer.camera.update(); renderer.begin(); renderer.drawSkeleton(active.skeleton, true); renderer.end();
  }
  /* 语音与动作解绑：动作本身不播语音，只有点击/戳一下从当前皮肤的语音池随机抽一条。
     基础形态只用基建向台词，战斗形态用整套日语语音；红女爵使用 it- 前缀的专属语音。 */
  const START_AUDIO = ['voice-07', 'voice-08'];
  const VOICE_SETS = {
    default: {
      count: 37,
      building: ['voice-01', 'voice-02', 'voice-16', 'voice-17', 'voice-18', 'voice-20'],
    },
    iteration: { count: 0, start: null, building: [] },
  };
  let lastVoice = '', lastPlayedAt = new Map();
  const VOICE_COOLDOWN_MS = 30000;
  function voicePool() {
    const iteration = active?.skin === 'iteration';
    const key = iteration ? 'iteration' : 'default';
    const set = VOICE_SETS[key];
    const prefix = iteration ? 'it-voice-' : 'voice-';
    const all = Array.from({ length: set.count }, (_, i) => prefix + String(i + 1).padStart(2, '0'));
    return active?.form === 'building' ? set.building : all;
  }
  function playClickVoice() {
    const pool = voicePool();
    if (!pool.length) return;
    const now = performance.now();
    const fresh = pool.filter((n) => now - (lastPlayedAt.get(n) ?? -Infinity) >= VOICE_COOLDOWN_MS);
    let choices = fresh.length ? fresh : pool.filter((n) => n !== lastVoice);
    if (!choices.length) choices = pool;
    const picked = choices[Math.floor(Math.random() * choices.length)];
    lastVoice = picked;
    lastPlayedAt.set(picked, now);
    opts.host.sound?.(picked, 'touch', true);
  }
  function playStartVoice() {
    const picked = START_AUDIO[Math.floor(Math.random() * START_AUDIO.length)];
    lastVoice = picked;
    lastPlayedAt.set(picked, performance.now());
    opts.host.sound?.(picked, 'touch', true);
  }
  const host = opts.host ? { ...opts.host,
    emit: (kind, detail) => { noteEvent(kind, detail); opts.host.emit?.(kind, detail); },
    sound: (name, kind, ...args) => {
      /* 点击只出一条语音；不把动作音、落地音和表情音绑到语音上。 */
      if (name === 'poke') { playClickVoice(); return; }
      opts.host.sound?.(name, kind, ...args);
    } } : opts.host;
  body = opts.kit.createBody(host, {
    words: WORDS,
    figure: {
      draw,
      words: WORDS,
      gestures: ['wave', 'bow'],
      anchors: { gaze: [148, 121], tear: [164, 136], tears: [[116, 136], [157, 136]], z: [190, 56], hearts: [92, 174, 48], bubble: [128, 4] },
      extent: [0, 0, 256, 256],
      hits: [[128, 142, 108], [128, 80, 70]],
      async setScheme(id) { await switchStyle(id); },
      dispose() {
        if (disposed) return;
        disposed = true;
        for (const model of models.values()) for (const texture of model.textures.values()) texture.dispose();
        models.clear(); renderer.dispose(); context.gl.getExtension('WEBGL_lose_context')?.loseContext();
        mounted = null; foreign = null; active = null;
      },
    },
  });
  const doKit = body.do.bind(body);
  kitDo = doKit;
  body.do = (word) => {
    /* battle sets carry no sleep pose: the word is simply refused there */
    if (word === 'sleep' && active?.form === 'battle') return false;
    return ACTION_WORDS.has(word) ? enqueue(word) : doKit(word);
  };
  return body;
}
